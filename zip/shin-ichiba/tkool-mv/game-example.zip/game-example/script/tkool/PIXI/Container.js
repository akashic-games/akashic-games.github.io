"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Container = exports.PixiEntity = void 0;
var Point_1 = require("./Point");
var ObservablePoint_1 = require("./ObservablePoint");
var core_1 = require("../core");
function mul(m1, m2) {
    return [
        m1[0] * m2[0] + m1[2] * m2[1],
        m1[1] * m2[0] + m1[3] * m2[1],
        m1[0] * m2[2] + m1[2] * m2[3],
        m1[1] * m2[2] + m1[3] * m2[3],
        m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
        m1[1] * m2[4] + m1[3] * m2[5] + m1[5]
    ];
}
var PixiEntity = /** @class */ (function (_super) {
    __extends(PixiEntity, _super);
    function PixiEntity(param) {
        var _this = _super.call(this, param) || this;
        _this.container = param.container;
        _this._anchor = { x: 0, y: 0 };
        return _this;
    }
    // 変更点:
    // * _anchor が有効なら !ContextLess に設定する
    // override
    PixiEntity.prototype.modified = function (isBubbling) {
        // _matrixの用途は描画に限らない(e.g. E#findPointSourceByPoint)ので、Modifiedフラグと無関係にクリアする必要がある
        if (this._matrix)
            this._matrix._modified = true;
        if (this.angle || this.scaleX !== 1 || this.scaleY !== 1 || this.opacity !== 1 || this.compositeOperation !== undefined ||
            this.shaderProgram !== undefined ||
            this._anchor.x !== 0 || this._anchor.y !== 0) {
            this.state &= ~8 /* g.EntityStateFlags.ContextLess */;
        }
        else {
            this.state |= 8 /* g.EntityStateFlags.ContextLess */;
        }
        if (this.state & 4 /* g.EntityStateFlags.Modified */)
            return;
        this.state |= 4 /* g.EntityStateFlags.Modified */;
        if (this.parent)
            this.parent.modified(true);
    };
    // 変更点:
    // * _anchor を加味する。
    // * Akashic独特の「回転の中心は画像の中心だが、位置は回転前の画像の左上で扱う」ではなくなる。
    // TODO: 機能追加がないようなら高速化する。
    // override
    PixiEntity.prototype._updateMatrix = function () {
        if (this.angle || this.scaleX !== 1 || this.scaleY !== 1 || this._anchor.x !== 0 || this._anchor.y !== 0) {
            // this._matrix.update(this.width, this.height, this.scaleX, this.scaleY, this.angle, this.x, this.y);
            var th = this.angle / 180 * Math.PI;
            var cos = Math.cos(th);
            var sin = Math.sin(th);
            this._matrix._matrix = mul(mul(mul([1, 0, 0, 1, this.x, this.y], [cos, -sin, sin, cos, 0, 0]), [this.scaleX, 0, 0, this.scaleY, 0, 0]), [1, 0, 0, 1, -this.container.width * this._anchor.x, -this.container.height * this._anchor.y]);
        }
        else {
            this._matrix.reset(this.x, this.y);
        }
    };
    // 変更点:
    // * `renderer.transform(this.getMatrix()._matrix);` に進む条件に `_anchor` 追加
    // override
    PixiEntity.prototype.render = function (renderer, camera) {
        this.state &= ~4 /* g.EntityStateFlags.Modified */;
        if (this.state & 1 /* g.EntityStateFlags.Hidden */)
            return;
        if (this.state & 8 /* g.EntityStateFlags.ContextLess */) {
            renderer.translate(this.x, this.y);
            // tslint:disable-next-line
            var goDown_1 = this.renderSelf(renderer, camera);
            if (goDown_1 && this.children) {
                var children = this.children;
                var len = children.length;
                for (var i = 0; i < len; ++i)
                    children[i].render(renderer, camera);
            }
            renderer.translate(-this.x, -this.y);
            return;
        }
        renderer.save();
        if (this.angle || this.scaleX !== 1 || this.scaleY !== 1 || this._anchor.x !== 0 || this._anchor.y !== 0) {
            // Note: this.scaleX/scaleYが0の場合描画した結果何も表示されない事になるが、特殊扱いはしない
            renderer.transform(this.getMatrix()._matrix);
        }
        else {
            // Note: 変形なしのオブジェクトはキャッシュもとらずtranslateのみで処理
            renderer.translate(this.x, this.y);
        }
        if (this.opacity !== 1)
            renderer.opacity(this.opacity);
        if (this.compositeOperation !== undefined) {
            var compStr = typeof this.compositeOperation === "string"
                ? this.compositeOperation
                : g.Util.compositeOperationStringTable[this.compositeOperation];
            renderer.setCompositeOperation(compStr);
        }
        if (this.shaderProgram !== undefined && renderer.isSupportedShaderProgram())
            renderer.setShaderProgram(this.shaderProgram);
        var goDown = this.renderSelf(renderer, camera);
        if (goDown && this.children) {
            // Note: concatしていないのでunsafeだが、render中に配列の中身が変わる事はない前提とする
            var children = this.children;
            for (var i = 0; i < children.length; ++i)
                children[i].render(renderer, camera);
        }
        renderer.restore();
    };
    // override
    PixiEntity.prototype.renderSelf = function (renderer, camera) {
        // if (
        // 	!this.container.hasOwnProperty("openness") ||
        // 	(this.container.hasOwnProperty("openness") && (this.container as any).openness > 0)
        // 	) {
        // 	return this.container.renderSelf(renderer, camera);
        // }
        return this.container.renderSelf(renderer, camera);
    };
    return PixiEntity;
}(g.E));
exports.PixiEntity = PixiEntity;
/**
 * PIXI.Container 相当品
 */
var Container = /** @class */ (function () {
    function Container(scene) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        var _this = this;
        this.pixiEntity = new PixiEntity({
            scene: scene,
            container: this
        });
        this.parent = null;
        this.children = [];
        this.alpha = 1.0;
        this.visible = true;
        this._zIndex = 0;
        this.z = 0;
        this._scale = new ObservablePoint_1.ObservablePoint(function (subject) {
            _this.pixiEntity.scaleX = subject.x;
            _this.pixiEntity.scaleY = subject.y;
            _this.modified();
        }, 1, 1);
        this.initialize.apply(this, args);
    }
    Object.defineProperty(Container.prototype, "scene", {
        get: function () {
            return this.pixiEntity.scene;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "x", {
        get: function () {
            return this.pixiEntity.x;
        },
        set: function (value) {
            this.pixiEntity.x = value;
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "y", {
        get: function () {
            return this.pixiEntity.y;
        },
        set: function (value) {
            this.pixiEntity.y = value;
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "scale", {
        get: function () {
            return this._scale;
        },
        set: function (value) {
            this._scale.set(value.x, value.y);
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "pivot", {
        // TODO: impl
        get: function () {
            return new Point_1.Point(0, 0);
        },
        set: function (value) {
            // TODO: impl
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "zIndex", {
        get: function () {
            return this._zIndex;
        },
        set: function (value) {
            this._zIndex = value;
            // TODO: sort
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "alpha", {
        get: function () {
            return this.pixiEntity.opacity;
        },
        set: function (value) {
            this.pixiEntity.opacity = value;
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "rotation", {
        get: function () {
            return this.pixiEntity.angle / 180 * Math.PI;
        },
        set: function (value) {
            this.pixiEntity.angle = value / Math.PI * 180;
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "opacity", {
        get: function () {
            return this.pixiEntity.opacity * 255;
        },
        set: function (value) {
            value = core_1.Utils.clamp(value, 0, 255);
            this.pixiEntity.opacity = value / 255;
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "visible", {
        get: function () {
            return this.pixiEntity.visible();
        },
        set: function (value) {
            if (value)
                this.pixiEntity.show();
            else
                this.pixiEntity.hide();
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "width", {
        get: function () {
            // return this.scale.x * this.getLocalBounds().width;
            // TODO: 以下のやり方はおそらく不正確なのでちゃんと
            return this.scale.x * this.pixiEntity.width;
        },
        set: function (value) {
            // const width = this.getLocalBounds().width;
            var width = this.pixiEntity.width;
            if (width !== 0) {
                this.scale.x = value / width;
            }
            else {
                this.scale.x = 1;
            }
            this._width = value;
            this.pixiEntity.width = value;
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Container.prototype, "height", {
        get: function () {
            // return this.scale.y * this.getLocalBounds().height;
            // TODO: 以下のやり方はおそらく不正確なのでちゃんと
            return this.scale.y * this.pixiEntity.height;
        },
        set: function (value) {
            // const height = this.getLocalBounds().height;
            var height = this.pixiEntity.height;
            if (height !== 0) {
                this.scale.y = value / height;
            }
            else {
                this.scale.y = 1;
            }
            this._height = value;
            this.pixiEntity.height = value;
            this.modified();
        },
        enumerable: false,
        configurable: true
    });
    Container.prototype.initialize = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        // noting to do.
    };
    Container.prototype.addChild = function (child) {
        if (child.parent) {
            child.parent.removeChild(child);
        }
        child.parent = this;
        this.children.push(child);
        this.pixiEntity.append(child.pixiEntity);
        return child;
    };
    Container.prototype.addChildAt = function (child, index) {
        if (child.parent) {
            child.parent.removeChild(child);
        }
        child.parent = this;
        this.children.splice(index, 0, child);
        this._addChildAt(this.pixiEntity, child.pixiEntity, index);
        return child;
    };
    Container.prototype.removeChild = function (child) {
        var index = this.children.indexOf(child);
        if (index === -1)
            return null;
        child.parent = null;
        // removeItems(this.children, index, 1);
        this.children.splice(index, 1);
        if (this.pixiEntity.children.indexOf(child.pixiEntity) >= 0) {
            this.pixiEntity.remove(child.pixiEntity);
        }
        else {
            console.warn("container's child is not entity's child, cancel removing");
        }
        return child;
    };
    Container.prototype.updateTransform = function () {
        if (!this.children) {
            return;
        }
        this.children.forEach(function (c) {
            var child = c;
            if (child.updateTransform) {
                child.updateTransform();
            }
        });
    };
    Container.prototype.update = function () {
        if (!this.children) {
            return;
        }
        this.children.forEach(function (c) {
            var child = c;
            if (child.update) {
                child.update();
            }
        });
    };
    Container.prototype.modified = function () {
        this.pixiEntity.modified();
    };
    Container.prototype.renderSelf = function (renderer, camera) {
        return true;
    };
    Container.prototype._addChildAt = function (self, child, index) {
        var target = index < self.children.length ? self.children[index] : null;
        if (target) {
            self.insertBefore(child, target);
        }
        else {
            self.append(child);
        }
        return self;
    };
    return Container;
}());
exports.Container = Container;
