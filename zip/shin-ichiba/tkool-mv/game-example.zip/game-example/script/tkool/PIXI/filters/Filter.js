Object.defineProperty(exports, "__esModule", { value: true });
exports.Filter = void 0;
// Pixiのfilterクラスの空実装。シェーダをスプライトに適用する仕組み、の模様
// http://pixijs.download/dev/docs/packages_core_src_filters_Filter.js.html
var Filter = /** @class */ (function () {
    function Filter() {
    }
    return Filter;
}());
exports.Filter = Filter;
