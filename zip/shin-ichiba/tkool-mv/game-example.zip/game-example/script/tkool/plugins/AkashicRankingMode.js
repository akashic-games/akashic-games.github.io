"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var managers_1 = require("../managers");
var DataManager_1 = require("../managers/DataManager");
var objects_1 = require("../objects");
var scenes_1 = require("../scenes");
var windows_1 = require("../windows");
//=============================================================================
// AkashicRankingMode.js
//=============================================================================
/*:
 * @plugindesc plugin for creating ranking-type nicolive games.
 * @author DWANGO Co., Ltd.
 *
 * @param scoreVariableNumber
 * @desc Variable number to use as SCORE.
 * @default 1
 *
 * @param totalTimeLimit
 * @desc Total game time limit. min:20, max:200.
 * @default 75
 *
 * @param titleTime
 * @desc Time to display title screen.
 * @default 5
 *
 * @param graceTime
 * @desc Waiting time after game ends.
 * @default 10
 *
 * @param prohibitMenu
 * @desc Whether to prohibit menu display during timer display. 1:yes 0:no.
 * @default 1
 *
 * @help This plugin does not provide plugin commands.
 *
 * This plugin is essential when creating ranking-type nicolive games.
 */
/*:ja
 * @plugindesc ランキング形式のニコ生ゲームを作るためのプラグイン
 * @author 株式会社ドワンゴ
 *
 * @param scoreVariableNumber
 * @desc スコアとして使用する変数番号
 * @default 1
 *
 * @param totalTimeLimit
 * @desc ゲームの総制限時間。最小値:20、最大値:200
 * @default 75
 *
 * @param titleTime
 * @desc タイトル画面を表示する時間
 * @default 5
 *
 * @param graceTime
 * @desc ゲーム終了後待機時間
 * @default 10
 *
 * @param prohibitMenu
 * @desc タイマー表示中にメニュー表示を禁止するかどうか。1:禁止する、0:禁止しない
 * @default 1
 *
 * @help このプラグインには、プラグインコマンドはありません。
 *
 * ランキング形式のニコ生ゲームを作る時にこのプラグインが必須です。
 */
(function () {
    // パラメータ取得
    var parameters = managers_1.PluginManager.parameters("AkashicRankingMode");
    var scoreVariableNumber = Number(parameters["scoreVariableNumber"] || 1);
    var totalTimeLimit = typeof g !== "undefined" && g.game.vars.totalTimeLimit ?
        g.game.vars.totalTimeLimit : Number(parameters["totalTimeLimit"] || 75);
    var titleTime = Number(parameters["titleTime"] || 5);
    var graceTime = Number(parameters["graceTime"] || 10);
    var prohibitMenu = Number(parameters["prohibitMenu"] || 1) !== 0;
    // スコア初期化
    if (typeof g !== "undefined") {
        g.game.vars.gameState = {
            score: 0
        };
    }
    // タイトル画面を自動的に飛ばす処理
    var _timerId = null;
    var _sceneTitleStart = scenes_1.Scene_Title.prototype.start;
    scenes_1.Scene_Title.prototype.start = function () {
        var _this = this;
        _sceneTitleStart.call(this);
        var scene = (typeof g === "undefined" ? window : g.game.scene());
        _timerId = scene.setTimeout(function () {
            scene.clearTimeout(_timerId);
            _timerId = null;
            _this.commandNewGame();
        }, titleTime * 1000);
    };
    // タイトルメニューを非表示にするための対応
    scenes_1.Scene_Title.prototype.isBusy = function () {
        return _timerId != null;
    };
    // スコアを反映させる処理
    var _gameVariablesSetValue = objects_1.Game_Variables.prototype.setValue;
    objects_1.Game_Variables.prototype.setValue = function (variableId, value) {
        _gameVariablesSetValue.call(this, variableId, value);
        if (variableId === scoreVariableNumber && typeof g !== "undefined") {
            g.game.vars.gameState.score = value;
        }
    };
    // タイマーの制限時間の書き換え
    objects_1.Game_Timer.prototype.start = function (_count) {
        var _a;
        var fps;
        if (typeof g === "undefined") {
            // RPGツクールでのfpsのデフォルト値は60
            fps = 60;
        }
        else {
            // Akashic Engine でのfpsのデフォルト値は30
            fps = (_a = g.game.fps) !== null && _a !== void 0 ? _a : 30;
        }
        var timeLimit = totalTimeLimit - titleTime - graceTime;
        this._frames = timeLimit * fps;
        this._working = true;
    };
    // メニュー画面から「ゲーム終了」の項目を削除する
    windows_1.Window_MenuCommand.prototype.addGameEndCommand = function () {
        // 「ゲーム終了」の項目をメニューにはいらないようにするため、このメソッドでは何も行わない
    };
    // prohibitMenuがONの場合、タイマー利用時はメニュー画面を利用禁止にする
    if (prohibitMenu) {
        var _sceneMapCallMenu_1 = scenes_1.Scene_Map.prototype.callMenu;
        scenes_1.Scene_Map.prototype.callMenu = function () {
            if (DataManager_1.$gameTimer && DataManager_1.$gameTimer.isWorking()) {
                return;
            }
            _sceneMapCallMenu_1.call(this);
        };
        var _gameInterpretercommand351_1 = objects_1.Game_Interpreter.prototype.command351;
        objects_1.Game_Interpreter.prototype.command351 = function () {
            if (DataManager_1.$gameTimer && DataManager_1.$gameTimer.isWorking()) {
                return true;
            }
            return _gameInterpretercommand351_1.call(this);
        };
    }
})();
