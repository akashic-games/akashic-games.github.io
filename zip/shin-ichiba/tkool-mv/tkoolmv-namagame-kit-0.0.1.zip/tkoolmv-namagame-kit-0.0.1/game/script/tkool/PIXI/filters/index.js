Object.defineProperty(exports, "__esModule", { value: true });
exports.ColorMatrixFilter = exports.Filter = void 0;
var Filter_1 = require("./Filter");
Object.defineProperty(exports, "Filter", { enumerable: true, get: function () { return Filter_1.Filter; } });
var ColorMatrixFilter_1 = require("./ColorMatrixFilter");
Object.defineProperty(exports, "ColorMatrixFilter", { enumerable: true, get: function () { return ColorMatrixFilter_1.ColorMatrixFilter; } });
