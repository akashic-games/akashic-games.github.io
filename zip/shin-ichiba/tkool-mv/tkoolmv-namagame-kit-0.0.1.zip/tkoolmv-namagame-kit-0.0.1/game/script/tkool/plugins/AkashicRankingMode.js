Object.defineProperty(exports, "__esModule", { value: true });
var managers_1 = require("../managers");
var objects_1 = require("../objects");
var scenes_1 = require("../scenes");
var windows_1 = require("../windows");
//=============================================================================
// AkashicRankingMode.js
//=============================================================================
/*:
 * @plugindesc at sideview battle, only display item/skill names.
 * @author DWANGO Co., Ltd.
 *
 * @param scoreVaruableNumber
 * @desc Variable number to use as SCORE.
 * @default 1
 *
 * @param totalTimeLimit
 * @desc Total game time limit. min:20, max:200.
 * @default 75
 *
 * @param titleTime
 * @desc Time to display title screen.
 * @default 5
 *
 * @param graceTime
 * @desc Waiting time after game ends.
 * @default 10
 *
 * @param displayTimer
 * @desc Whether to display timer. 1:yes 0:no.
 * @default 1
 *
 * @help This plugin does not provide plugin commands.
 *
 * This plugin is essential when creating ranking-type nocilive games.
 */
/*:ja
 * @plugindesc ランキング形式のニコ生ゲームを作るためのプラグイン
 * @author 株式会社ドワンゴ
 *
 * @param scoreVaruableNumber
 * @desc スコアとして使用する変数番号
 * @default 1
 *
 * @param totalTimeLimit
 * @desc ゲームの総制限時間。最小値:20、最大値:200
 * @default 75
 *
 * @param titleTime
 * @desc タイトル画面を表示する時間
 * @default 5
 *
 * @param graceTime
 * @desc ゲーム終了後待機時間
 * @default 10
 *
 * @param displayTimer
 * @desc タイマーを表示するかどうか。1:表示、0:非表示
 * @default 1
 *
 * @help このプラグインには、プラグインコマンドはありません。
 *
 * ランキング形式のニコ生ゲームを作る時にこのプラグインが必須です。
 */
(function () {
    // パラメータ取得
    var parameters = managers_1.PluginManager.parameters("AkashicRankingMode");
    var scoreVaruableNumber = Number(parameters["scoreVaruableNumber"] || 1);
    var totalTimeLimit = typeof g !== "undefined" && g.game.vars.totalTimelimt ?
        g.game.vars.totalTimeLimit : Number(parameters["totalTimeLimit"] || 75);
    var titleTime = Number(parameters["titleTime"] || 5);
    var graceTime = Number(parameters["graceTime"] || 10);
    var displayTimer = Number(parameters["displayTimer"]) !== 0;
    // スコア初期化
    if (typeof g !== "undefined") {
        g.game.vars.gameState = {
            score: 0
        };
    }
    // タイトル画面を自動的に飛ばす処理
    var _timerId = null;
    var _sceneTitleStart = scenes_1.Scene_Title.prototype.start;
    scenes_1.Scene_Title.prototype.start = function () {
        var _this = this;
        _sceneTitleStart.call(this);
        var scene = (typeof g === "undefined" ? window : g.game.scene());
        _timerId = scene.setTimeout(function () {
            scene.clearTimeout(_timerId);
            _timerId = null;
            _this.commandNewGame();
        }, titleTime * 1000);
    };
    // タイトルメニューを非表示にするための対応
    scenes_1.Scene_Title.prototype.isBusy = function () {
        return _timerId != null;
    };
    // スコアを反映させる処理
    var _gameVariablesSetValue = objects_1.Game_Variables.prototype.setValue;
    objects_1.Game_Variables.prototype.setValue = function (variableId, value) {
        _gameVariablesSetValue.call(this, variableId, value);
        if (variableId === scoreVaruableNumber && typeof g !== "undefined") {
            g.game.vars.gameState.score = value;
        }
    };
    // タイマーの制限時間の書き換え
    objects_1.Game_Timer.prototype.start = function (_count) {
        var _a;
        var fps;
        if (typeof g === "undefined") {
            // RPGツクールでのfpsのデフォルト値は60
            fps = 60;
        }
        else {
            // Akashic Engine でのfpsのデフォルト値は30
            fps = (_a = g.game.fps) !== null && _a !== void 0 ? _a : 30;
        }
        var timeLimit = totalTimeLimit - titleTime - graceTime;
        this._frames = timeLimit * fps;
        this._working = displayTimer;
    };
    // メニュー画面から「ゲーム終了」の項目を削除する
    windows_1.Window_MenuCommand.prototype.addGameEndCommand = function () {
        // 「ゲーム終了」の項目をメニューにはいらないようにするため、このメソッドでは何も行わない
    };
    // メニュー画面でタイマーが止まってしまうので、タイマー表示時はメニュー画面を利用禁止にする
    if (displayTimer) {
        scenes_1.Scene_Map.prototype.callMenu = function () {
            // メニュー表示機能を停止するために、このメソッドでは何も行わない
        };
        objects_1.Game_Interpreter.prototype.command351 = function () {
            // メニュー表示機能を停止するために、このメソッドではtrueを返す以外何も行わない
            return true;
        };
    }
})();
