function main(param) {
	var scene = new g.Scene({
		game: g.game,
		// このシーンで利用するアセットのIDを列挙し、シーンに通知します
		assetIds: ["se"]
	});
	scene.onLoad.add(function () {
		// クリックで音を鳴らす
		scene.onPointDownCapture.add(function () {
			scene.asset.getAudioById("se").play();
		});
	});
	g.game.pushScene(scene);
}
module.exports = main;
