function main(_param) {
	var scene = new g.Scene({
		game: g.game,
		assetIds: ["player"]
	});
	var camera = new g.Camera2D({});
	g.game.focusingCamera = camera;

	scene.onLoad.add(function () {
		var sprite = new g.Sprite({
			scene: scene,
			src: scene.asset.getImageById("player")
		});
		scene.append(sprite);
	});
	scene.onPointDownCapture.add(function (ev) {
		if (ev.player.id === g.game.selfId) {
			camera.x -= 10; // 画面表示の X 座標位置を -10 移動する
			camera.modified();
			g.game.modified();
		}
	});
	g.game.pushScene(scene);
}
module.exports = main;
